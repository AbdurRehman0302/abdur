Riders and Drivers can register themselves in the application with thier respective roles. Riders can view the real time location with the help of socketio of all the drivers within thier vicinity (2km radius).
Riders can choose thier pickup and drop off location using markers or bu using google place auto-complete. Riders can requset a ride which will be forwarded to drivers within the radius(2km).
Drivers will recieve the ride request and can see where the rider is which route should be take to pick him up and can also see what the riders destination is.
Drivers can use the in-app real time maps navigation to follow the route or they can use google map provided through linking for real time maps navigation.


Rider App

![WhatsApp Image 2023-12-25 at 3 36 52 PM (2)](https://github.com/Bilal-Ahmad123/Taxi/assets/80017963/536178b8-a1ae-49e4-a9bc-7f52cc106651)
![WhatsApp Image 2023-12-25 at 3 36 53 PM](https://github.com/Bilal-Ahmad123/Taxi/assets/80017963/8f22883e-7a6b-4cb0-93c0-7a3e251899a9)
![WhatsApp Image 2023-12-25 at 3 36 51 PM](https://github.com/Bilal-Ahmad123/Taxi/assets/80017963/1b00ce03-2431-4e22-9c29-e3b1efbb7bed)
![WhatsApp Image 2023-12-25 at 3 36 51 PM (1)](https://github.com/Bilal-Ahmad123/Taxi/assets/80017963/e78189d7-16da-4cb6-b237-4d0c3998591f)
![WhatsApp Image 2023-12-25 at 3 36 51 PM (2)](https://github.com/Bilal-Ahmad123/Taxi/assets/80017963/978adc8f-86b4-4f90-b1e9-e3e705c80795)
![WhatsApp Image 2023-12-25 at 3 36 52 PM](https://github.com/Bilal-Ahmad123/Taxi/assets/80017963/30696b8c-8b63-4cce-ad15-806289c0fde7)
![WhatsApp Image 2023-12-25 at 3 36 52 PM (1)](https://github.com/Bilal-Ahmad123/Taxi/assets/80017963/7526db5e-14a5-49e0-a5ee-0c84d5d8fbd3)

Driver App

![WhatsApp Image 2023-12-25 at 3 48 33 PM](https://github.com/Bilal-Ahmad123/Taxi/assets/80017963/53e622c1-2b8c-4006-9bce-8ff7f4740852)
![WhatsApp Image 2023-12-25 at 3 48 33 PM (1)](https://github.com/Bilal-Ahmad123/Taxi/assets/80017963/5fa38336-be48-42cc-9b0c-54e485da5fe4)
![WhatsApp Image 2023-12-25 at 3 48 34 PM](https://github.com/Bilal-Ahmad123/Taxi/assets/80017963/c0241857-0bf9-4cb9-bb71-cb81deeb5a67)
