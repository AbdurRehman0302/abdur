import {createContext, useContext, useState} from 'react';

export const mySocket = createContext();
