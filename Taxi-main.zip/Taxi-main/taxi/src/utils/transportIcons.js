export const images = [
  {uri: require('../../assets/transportIcons/1.png'), title: 'Ac'},
  {uri: require('../../assets/transportIcons/2.png'), title: 'Ride'},
  {uri: require('../../assets/transportIcons/3.png'), title: 'Ride Mini'},
  {uri: require('../../assets/transportIcons/4.png'), title: 'Bike'},
  {uri: require('../../assets/transportIcons/5.png'), title: 'City to city'},
  {uri: require('../../assets/transportIcons/6.png'), title: 'Courier'},
  {
    uri: require('../../assets/transportIcons/7.png'),
    title: 'Truck: city to city',
  },
  {uri: require('../../assets/transportIcons/8.png'), title: 'Freight'},
];
